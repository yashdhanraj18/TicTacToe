package com.example.tictactoe;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button[][] buttons = new Button[3][3];
    private boolean player1Turn = true;
    private int roundCount = 0;
    private TextView textViewStatus;
    private Button buttonReset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewStatus = findViewById(R.id.text_view_status);
        buttonReset = findViewById(R.id.button_reset);

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                String buttonID = "button_" + i + j;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i][j] = findViewById(resID);
                buttons[i][j].setOnClickListener(this);
            }
        }

        buttonReset.setOnClickListener(v -> resetGame());
    }

    @Override
    public void onClick(View v) {
        Button clicked = (Button) v;
        if (!clicked.getText().toString().equals("")) return;

        clicked.setText(player1Turn ? "X" : "O");
        roundCount++;

        if (checkForWin()) {
            textViewStatus.setText(player1Turn ? "Player 1 Wins!" : "Player 2 Wins!");
            disableAllButtons();
        } else if (roundCount == 9) {
            textViewStatus.setText("Draw!");
        } else {
            player1Turn = !player1Turn;
            textViewStatus.setText(player1Turn ? "Player 1's Turn (X)" : "Player 2's Turn (O)");
        }
    }

    private boolean checkForWin() {
        String[][] field = new String[3][3];
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                field[i][j] = buttons[i][j].getText().toString();

        for (int i = 0; i < 3; i++) {
            if (!field[i][0].equals("") && field[i][0].equals(field[i][1]) && field[i][0].equals(field[i][2]))
                return true;
            if (!field[0][i].equals("") && field[0][i].equals(field[1][i]) && field[0][i].equals(field[2][i]))
                return true;
        }

        if (!field[0][0].equals("") && field[0][0].equals(field[1][1]) && field[0][0].equals(field[2][2]))
            return true;
        return !field[0][2].equals("") && field[0][2].equals(field[1][1]) && field[0][2].equals(field[2][0]);
    }

    private void disableAllButtons() {
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                buttons[i][j].setEnabled(false);
    }

    private void resetGame() {
        roundCount = 0;
        player1Turn = true;
        textViewStatus.setText("Player 1's Turn (X)");

        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setText("");
                buttons[i][j].setEnabled(true);
            }
    }
}
